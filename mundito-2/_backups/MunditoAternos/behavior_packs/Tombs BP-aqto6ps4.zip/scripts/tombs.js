import {
    ItemTypes,
    ItemStack,
    MinecraftBlockTypes,
    system,
    world,
} from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const setTomb = (player, dimension, playerLocation) => {
    const oneTag = player.hasTag("oneTag"),
        twoTag = player.hasTag("twoTag"),
        threeTag = player.hasTag("threeTag"),
        fourTag = player.hasTag("fourTag"),
        fiveTag = player.hasTag("fiveTag");

    if (oneTag) {
        dimension.fillBlocks(
            playerLocation,
            playerLocation,
            MinecraftBlockTypes.get("tomb:tomb_1")
        );
    } else if (twoTag) {
        dimension.fillBlocks(
            playerLocation,
            playerLocation,
            MinecraftBlockTypes.get("tomb:tomb_2")
        );
    } else if (threeTag) {
        dimension.fillBlocks(
            playerLocation,
            playerLocation,
            MinecraftBlockTypes.get("tomb:tomb_3")
        );
    } else if (fourTag) {
        dimension.fillBlocks(
            playerLocation,
            playerLocation,
            MinecraftBlockTypes.get("tomb:tomb_4")
        );
    } else if (fiveTag) {
        dimension.fillBlocks(
            playerLocation,
            playerLocation,
            MinecraftBlockTypes.get("tomb:tomb_5")
        );
    } else {
        dimension.fillBlocks(
            playerLocation,
            playerLocation,
            MinecraftBlockTypes.get("tomb:tomb_1")
        );
    }
};

const tombKey = (player) => {
    let inventory = player.getComponent("inventory").container,
        tombKeyItem = new ItemStack(ItemTypes.get("tomb:tomb_key"), 1),
        dummyTag = player.getTags().find((tag) => tag.includes("tombTag")),
        dummyArray = dummyTag.replace("tombTag", "").split(",");

    tombKeyItem.setLore([
        `Player: ${dummyArray[0]}`,
        `Dimension: ${dummyArray[1]}`,
        `x: ${dummyArray[2]}, y: ${dummyArray[3]}, z: ${dummyArray[4]}`,
    ]);

    player.removeTag(dummyTag);
    inventory.addItem(tombKeyItem);
};

const getEquipmentSlot = (EquipmentComponent) => {
    let headSlot = EquipmentComponent.getEquipmentSlot("head");
    let chestSlot = EquipmentComponent.getEquipmentSlot("chest");
    let leggingsSlot = EquipmentComponent.getEquipmentSlot("legs");
    let feetSlot = EquipmentComponent.getEquipmentSlot("feet");
    let offHandSlot = EquipmentComponent.getEquipmentSlot("offhand");
    return [headSlot, chestSlot, leggingsSlot, feetSlot, offHandSlot];
};

let playerInventoriesMain = {};

system.events.beforeWatchdogTerminate.subscribe((dataEvent) => {
    dataEvent.cancel = true;
});

system.runInterval(() => {
    let players = world.getPlayers();

    for (let player of players) {
        let currentHealth = player.getComponent("minecraft:health").current;
        if (currentHealth <= 0) continue;
        let name = player.name;
        let getInventory = player.getComponent("inventory").container;
        let getEquipments = getEquipmentSlot(
            player.getComponent("minecraft:equipment_inventory")
        );
        let playerInventory = [];

        for (let i = 0; i < getInventory.size; i++) {
            if (!getInventory.getItem(i)) continue;
            playerInventory.push(getInventory.getItem(i));
        }
        for (let equipment of getEquipments) {
            if (!equipment.getItem()) continue;
            playerInventory.push(equipment.getItem());
        }
        playerInventoriesMain[`${name}`] = playerInventory;
    }
}, 3);

system.runInterval(() => {
    let players = world.getPlayers();
    for (let player of players) {
        let currentHealth = player.getComponent("health").current;
        let deathTag = player.hasTag("tomb_death");

        if (currentHealth > 0 && deathTag) {
            player.removeTag("tomb_death");
            tombKey(player);
        }
    }
}, 10);

world.afterEvents.entityDie.subscribe((dataEvent) => {
    const player = dataEvent.deadEntity,
        name = player.name;
    const dimension = player.dimension,
        playerLocation = {
            x: Math.round(player.location.x),
            y: Math.round(player.location.y),
            z: Math.round(player.location.z),
        },
        entityLocation = {
            x: Math.round(player.location.x) + 0.5,
            y: Math.round(player.location.y),
            z: Math.round(player.location.z) + 0.5,
        };

    try {
        if (!player.typeId === "minecraft:player") return;
        if (playerInventoriesMain[name].length === 0) {
            system.run(() => {
                player.runCommandAsync(
                    `tellraw @s {"rawtext":[{"text":"§cYou died in\n§r[${playerLocation.x}, y: ${playerLocation.y}, z: ${playerLocation.z}] in ${dimension.id}"}]}`
                );
            });
            return;
        }
    } catch (error) {
        return;
    }

    const tombEntity = dimension.spawnEntity(
        "tomb:tomb_container",
        entityLocation
    );
    tombEntity.nameTag = name + "'s Tomb";
    // tombEntity.addTag(
    //     `tombEntityTag${player.name},${dimension.id},${playerLocation.x},${playerLocation.y},${playerLocation.z}`
    // );

    let tombContainer = tombEntity.getComponent("inventory").container;

    for (let playerItems of playerInventoriesMain[name]) {
        tombContainer.addItem(playerItems);
    }

    player.runCommandAsync(
        `tellraw @s {"rawtext":[{"text":"§aA new tomb with your lost items was created in\n§r[x: ${playerLocation.x}, y: ${playerLocation.y}, z: ${playerLocation.z}] in ${dimension.id}"}]}`
    );

    let playerItemEntities = player.dimension.getEntities({
        type: "minecraft:item",
        maxDistance: 2,
        location: player.location,
    });

    for (let itemEntity of playerItemEntities) {
        itemEntity.kill();
    }

    player.addTag("tomb_death");
    player.addTag(
        `tombTag${player.name},${dimension.id},${playerLocation.x},${playerLocation.y},${playerLocation.z}`
    );

    setTomb(player, dimension, playerLocation);
});

world.beforeEvents.itemUse.subscribe((dataEvent) => {
    const item = dataEvent.itemStack,
        player = dataEvent.source;
    switch (item.typeId) {
        case "tomb:key_config":
            system.run(() => {
                const form = new ActionFormData()
                    .title("Tombs")
                    .button("Model 1", "textures/ui/tombs/tomb_1")
                    .button("Model 2", "textures/ui/tombs/tomb_2")
                    .button("Model 3", "textures/ui/tombs/tomb_3")
                    .button("Model 4", "textures/ui/tombs/tomb_4")
                    .button("Model 5", "textures/ui/tombs/tomb_5");

                form.show(player).then(async (response) => {
                    if (response.selection === 0) {
                        player.addTag("oneTag");
                        player.removeTag("twoTag");
                        player.removeTag("threeTag");
                        player.removeTag("fourTag");
                        player.removeTag("fiveTag");
                    } else if (response.selection === 1) {
                        player.removeTag("oneTag");
                        player.addTag("twoTag");
                        player.removeTag("threeTag");
                        player.removeTag("fourTag");
                        player.removeTag("fiveTag");
                    } else if (response.selection === 2) {
                        player.removeTag("oneTag");
                        player.removeTag("twoTag");
                        player.addTag("threeTag");
                        player.removeTag("fourTag");
                        player.removeTag("fiveTag");
                    } else if (response.selection === 3) {
                        player.removeTag("oneTag");
                        player.removeTag("twoTag");
                        player.removeTag("threeTag");
                        player.addTag("fourTag");
                        player.removeTag("fiveTag");
                    } else if (response.selection === 4) {
                        player.removeTag("oneTag");
                        player.removeTag("twoTag");
                        player.removeTag("threeTag");
                        player.removeTag("fourTag");
                        player.addTag("fiveTag");
                    }
                });
            });
            break;

        // case "tomb:tomb_key":
        //     system.run(() => {
        //         let inventory = player.getComponent("inventory").container;
        //         let item = inventory.getItem(player.selectedSlot);
        //         let lore = item.getLore().toString();
        //         let compareLore = lore
        //             .replace("Player:", "")
        //             .replace("Dimension:", "")
        //             .replace("x:", "")
        //             .replace("y:", "")
        //             .replace("z:", "")
        //             .replace(/ /g, "")
        //             .trim();

        //         // player.runCommandAsync(
        //         //     `tp @s @e[tag="tombEntityTag${compareLore}"]`
        //         // );
        //     });
        //     break;

        default:
            break;
    }
});

world.beforeEvents.itemUseOn.subscribe((dataEvent) => {
    let player = dataEvent.source,
        item = dataEvent.itemStack,
        name = player.name;

    let blockTest = player.getBlockFromViewDirection(),
        blockDim = blockTest.dimension.id,
        blockLoc = {
            x: Math.round(blockTest.location.x),
            y: Math.round(blockTest.location.y),
            z: Math.round(blockTest.location.z),
        };

    let key = item.typeId == "tomb:tomb_key",
        blockId = blockTest.typeId;

    if (
        key &&
        (blockId == "tomb:tomb_1" ||
            blockId == "tomb:tomb_2" ||
            blockId == "tomb:tomb_3" ||
            blockId == "tomb:tomb_4" ||
            blockId == "tomb:tomb_5")
    ) {
        let inventory = player.getComponent("inventory").container;
        let currentItem = inventory.getItem(player.selectedSlot);
        let slot = player.selectedSlot;

        let getLore = currentItem.getLore().toString(),
            loreArray = getLore.split(","),
            loreClean = {
                player: loreArray[0].replace("Player: ", "").trim(),
                dimension: loreArray[1].replace("Dimension: ", "").trim(),
                x: parseInt(loreArray[2].replace("x: ", "").trim()),
                y: parseInt(loreArray[3].replace("y: ", "").trim()),
                z: parseInt(loreArray[4].replace("z: ", "").trim()),
            };

        if (
            loreClean.player === name &&
            loreClean.dimension === blockDim &&
            loreClean.x === blockLoc.x &&
            loreClean.y === blockLoc.y &&
            loreClean.z === blockLoc.z
        ) {
            system.run(() => {
                player.runCommandAsync(
                    `setblock ${blockLoc.x} ${blockLoc.y} ${blockLoc.z} air`
                );
                player.runCommandAsync(
                    `titleraw @s actionbar {"rawtext":[{"text":"§aYou opened the tomb"}]}`
                );

                inventory.setItem(slot, undefined);
            });
        } else if (
            loreClean.player === name &&
            (loreClean.dimension !== blockDim ||
                loreClean.x !== blockLoc.x ||
                loreClean.y !== blockLoc.y ||
                loreClean.z !== blockLoc.z)
        ) {
            system.run(() => {
                player.runCommandAsync(
                    `titleraw @s actionbar {"rawtext":[{"text":"§cThe key doesn't correspond to the tomb"}]}`
                );
            });
        } else if (
            loreClean.player !== name &&
            loreClean.dimension === blockDim &&
            loreClean.x === blockLoc.x &&
            loreClean.y === blockLoc.y &&
            loreClean.z === blockLoc.z
        ) {
            system.run(() => {
                player.runCommandAsync(
                    `titleraw @s actionbar {"rawtext":[{"text":"§cYou don't own the tomb"}]}`
                );
            });
        } else if (
            loreClean.player !== name &&
            (loreClean.dimension !== blockDim ||
                loreClean.x !== blockLoc.x ||
                loreClean.y !== blockLoc.y ||
                loreClean.z !== blockLoc.z)
        ) {
            system.run(() => {
                player.runCommandAsync(
                    `titleraw @s actionbar {"rawtext":[{"text":"§cYou don't own the tomb or the key doesn't correspond"}]}`
                );
            });
        }
    }
});
