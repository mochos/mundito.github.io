let mobs = [
  {
    variant: 0,
    hurt: "game.player.hurt",
    death: "game.player.die",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 1,
    hurt: "mob.zombie.hurt",
    death: "mob.zombie.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 2,
    hurt: "mob.cow.hurt",
    death: "mob.cow.hurt",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 3,
    hurt: {
      sound: "mob.skeleton.hurt",
      volume: 0.70
    },
    death: "mob.skeleton.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 4,
    hurt: "mob.chicken.hurt",
    death: "mob.chicken.hurt",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 5,
    hurt: "mob.creeper.say",
    death: "mob.creeper.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 6,
    hurt: "mob.sheep.say",
    death: "mob.sheep.say",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 7,
    hurt: "mob.spider.say",
    death: "mob.spider.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 8,
    hurt: "mob.pig.say",
    death: "mob.pig.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 9,
    hurt: "mob.endermen.hit",
    death: "mob.endermen.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 10,
    hurt: "mob.bat.hurt",
    death: "mob.bat.death",
    volume: 0.10,
    pitch: [ 0.76, 1.14 ]
  },
  {
    variant: 11,
    hurt: "mob.zombiepig.zpighurt",
    death: "mob.zombiepig.zpigdeath",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 12,
    hurt: "mob.fox.hurt",
    death: "mob.fox.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 13,
    hurt: "mob.drowned.hurt",
    death: "mob.drowned.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 14,
    hurt: "mob.villager.hit",
    death: "mob.villager.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 15,
    hurt: {
      sound: "mob.skeleton.hurt",
      volume: 0.70
    },
    death: "mob.skeleton.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 16,
    hurt: "mob.snowgolem.hurt",
    death: "mob.snowgolem.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 17,
    hurt: "mob.blaze.hit",
    death: "mob.blaze.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 18,
    hurt: {
      sound: "mob.cat.hit",
      volume: 0.45
    },
    death: {
      sound: "mob.cat.hit",
      volume: 0.50,
      pitch: 0.90
    },
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 19,
    hurt: "mob.husk.hurt",
    death: "mob.husk.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 20,
    hurt: "mob.wolf.hurt",
    death: "mob.wolf.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 21,
    hurt: "mob.piglin.hurt",
    death: "mob.piglin.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 22,
    hurt: "mob.fish.hurt",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 23,
    hurt: "mob.irongolem.hit",
    death: "mob.irongolem.death",
    volume: 1.0,
    pitch: [ 0.80, 1.0 ]
  },
  {
    variant: 24,
    hurt: "mob.axolotl.hurt",
    death: "mob.axolotl.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 25,
    hurt: "mob.stray.hurt",
    death: "mob.stray.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 26,
    hurt: {
      sound: "mob.cat.hit",
      volume: 0.45
    },
    death: "mob.ocelot.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 27,
    hurt: "mob.vindicator.hurt",
    death: "mob.vindicator.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 28,
    hurt: "mob.fish.hurt",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 29,
    hurt: "mob.hoglin.hurt",
    death: "mob.hoglin.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 30,
    hurt: "mob.squid.hurt",
    death: "mob.squid.death",
    volume: 0.40,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 31,
    hurt: "mob.piglin_brute.hurt",
    death: "mob.piglin_brute.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 32,
    hurt: "mob.llama.hurt",
    death: "mob.llama.death",
    volume: 0.80,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 33,
    hurt: "mob.spider.say",
    death: "mob.spider.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 34,
    hurt: "mob.cow.hurt",
    death: "mob.cow.hurt",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 35,
    hurt: "mob.zombie_villager.hurt",
    death: "mob.zombie_villager.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 36,
    hurt: [
      { condition: "entity.getComponent('minecraft:mark_variant').value == 0", sound: "mob.goat.hurt" },
      { condition: "entity.getComponent('minecraft:mark_variant').value == 1", sound: "mob.goat.hurt.screamer" }
    ],
    death: [
      { condition: "entity.getComponent('minecraft:mark_variant').value == 0", sound: "mob.goat.death" },
      { condition: "entity.getComponent('minecraft:mark_variant').value == 1", sound: "mob.goat.death.screamer" }
    ],
    volume: 1,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 37,
    hurt: "mob.wither.hurt",
    death: "mob.wither.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 38,
    hurt: "mob.dolphin.hurt",
    death: "mob.dolphin.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 39,
    hurt: "mob.zoglin.hurt",
    death: "mob.zoglin.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 40,
    hurt: {
      sound: "mob.bee.hurt",
      volume: 0.60,
      pitch: [ 0.90, 1.10 ]
    },
    death: {
      sound: "mob.bee.death",
      volume: 0.60,
      pitch: [ 0.90, 1.10 ]
    },
    volume: 0.60,
    pitch: 1.0
  },
  {
    variant: 41,
    hurt: "mob.pillager.hurt",
    death: "mob.pillager.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 42,
    hurt: {
      sound: "mob.parrot.hurt",
      volume: 1.0,
      pitch: [ 0.80, 1.0 ]
    },
    death: {
      sound: "mob.parrot.death",
      volume: 1.0,
      pitch: [ 0.80, 1.0 ]
    },
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 43,
    hurt: "mob.slime.small",
    death: "mob.slime.small",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 44,
    hurt: "mob.strider.hurt",
    death: "mob.strider.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 45,
    hurt: "mob.vex.hurt",
    death: "mob.vex.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 46,
    hurt: [
      { condition: "!entity.getComponent('minecraft:is_baby')", sound: "mob.turtle.hurt" },
      { condition: "entity.getComponent('minecraft:is_baby')", sound: "mob.turtle_baby.hurt" }
    ],
    death: [
      { condition: "!entity.getComponent('minecraft:is_baby')", sound: "mob.turtle.death" },
      { condition: "entity.getComponent('minecraft:is_baby')", sound: "mob.turtle_baby.death" }
    ],
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 47,
    hurt: "mob.witch.hurt",
    death: "mob.witch.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 48,
    hurt: "mob.rabbit.hurt",
    death: "mob.rabbit.death",
    volume: 0.80,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 49,
    hurt: "mob.ghast.scream",
    death: "mob.ghast.death",
    volume: 600.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 50,
    hurt: "mob.glow_squid.hurt",
    death: "mob.glow_squid.death",
    volume: 0.40,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 51,
    hurt: "mob.phantom.hurt",
    death: "mob.phantom.death",
    volume: 10.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 52,
    hurt: {
      sound: "mob.polarbear.hurt",
      volume: 0.70
    },
    death: "mob.polarbear.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 53,
    hurt: "mob.magmacube.small",
    death: "mob.magmacube.small",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 54,
    hurt: "mob.allay.hurt",
    death: "mob.allay.death",
    volume: 1,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 55,
    hurt: "mob.ravager.hurt",
    death: "mob.ravager.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 56,
    hurt: "mob.frog.hurt",
    death: "mob.frog.death",
    volume: 1,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 57,
    hurt: "mob.evocation_illager.hurt",
    death: "mob.evocation_illager.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 58,
    hurt: "mob.tadpole.hurt",
    death: "mob.tadpole.death",
    volume: 1,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 59,
    hurt: "mob.endermite.hit",
    death: "mob.endermite.kill",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 60,
    hurt: "mob.wanderingtrader.hurt",
    death: "mob.wanderingtrader.death",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 61,
    hurt: "mob.silverfish.hit",
    death: "mob.silverfish.kill",
    volume: 1.0,
    pitch: [ 0.80, 1.20 ]
  },
  {
    variant: 62,
    hurt: "mob.llama.hurt",
    death: "mob.llama.death",
    volume: 0.80,
    pitch: [ 0.80, 1.20 ]
  }
];


import { world } from "@minecraft/server";

world.afterEvents.entityHurt.subscribe(data => {
  const { hurtEntity } = data;
  if (hurtEntity.typeId == "minecraft:player") {
    for (let i = 0; i < mobs.length; i++) {
      if (mobs[i].variant == hurtEntity.getComponent("minecraft:variant").value) {
        let sound = {
          pitch: (Array.isArray(mobs[i].pitch) ? range(mobs[i].pitch): mobs[i].pitch) + (hurtEntity.getComponent("minecraft:is_baby") ? 0.5: 0),
          volume: mobs[i].volume
        };
        if (hurtEntity.getComponent("minecraft:health").current > 0) {
          if (mobs[i].hurt != undefined) {
            if (typeof mobs[i].hurt == "object") {
              if (Array.isArray(mobs[i].hurt)) {
                for (let n = 0; n < mobs[i].hurt.length; n++) {
                  if (mobs[i].hurt[n].pitch != undefined) { sound.pitch = (Array.isArray(mobs[i].hurt[n].pitch) ? range(mobs[i].hurt[n].pitch): mobs[i].hurt[n].pitch) + (hurtEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
                  if (mobs[i].hurt[n].volume != undefined) { sound.volume = mobs[i].hurt[n].volume; };
                  if (mobs[i].hurt[n].condition == undefined ? true: eval(mobs[i].hurt[n].condition.replace(new RegExp("\\bentity\\b","g"), "hurtEntity"))) {
                    world.playSound(mobs[i].hurt[n].sound, hurtEntity.location, sound);
                  };
                };
              } else {
                if (mobs[i].hurt.pitch != undefined) { sound.pitch = (Array.isArray(mobs[i].hurt.pitch) ? range(mobs[i].hurt.pitch): mobs[i].hurt.pitch) + (hurtEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
                if (mobs[i].hurt.volume != undefined) { sound.volume = mobs[i].hurt.volume; };
                if (mobs[i].hurt.condition == undefined ? true: eval(mobs[i].hurt.condition.replace(new RegExp("\\bentity\\b","g"), "hurtEntity"))) {
                  world.playSound(mobs[i].hurt.sound, hurtEntity.location, sound);
                };
              };
            } else { world.playSound(mobs[i].hurt, hurtEntity.location, sound); };
          } else { world.playSound("game.player.hurt", hurtEntity.location, sound); };
        };
      };
    };
  };
});

world.afterEvents.entityDie.subscribe(data => {
  const { deadEntity } = data;
  if (deadEntity.typeId == "minecraft:player") {
    for (let i = 0; i < mobs.length; i++) {
      if (mobs[i].variant == deadEntity.getComponent("minecraft:variant").value) {
        let sound = {
          pitch: (Array.isArray(mobs[i].pitch) ? range(mobs[i].pitch): mobs[i].pitch) + (deadEntity.getComponent("minecraft:is_baby") ? 0.5: 0),
          volume: mobs[i].volume
        };
        if (mobs[i].death != undefined) {
          if (typeof mobs[i].death == "object") {
            if (Array.isArray(mobs[i].death)) {
              for (let n = 0; n < mobs[i].death.length; n++) {
                if (mobs[i].death[n].pitch != undefined) { sound.pitch = (Array.isArray(mobs[i].death[n].pitch) ? range(mobs[i].death[n].pitch): mobs[i].death[n].pitch) + (deadEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
                if (mobs[i].death[n].volume != undefined) { sound.volume = mobs[i].death[n].volume; };
                if (mobs[i].death[n].condition == undefined ? true: eval(mobs[i].death[n].condition.replace(new RegExp("\\bentity\\b","g"), "deadEntity"))) {
                  world.playSound(mobs[i].death[n].sound, deadEntity.location, sound);
                };
              };
            } else {
              if (mobs[i].death.pitch != undefined) { sound.pitch = (Array.isArray(mobs[i].death.pitch) ? range(mobs[i].death.pitch): mobs[i].death.pitch) + (deadEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
              if (mobs[i].death.volume != undefined) { sound.volume = mobs[i].death.volume; };
              if (mobs[i].death.condition == undefined ? true: eval(mobs[i].death.condition.replace(new RegExp("\\bentity\\b","g"), "deadEntity"))) {
                world.playSound(mobs[i].death.sound, deadEntity.location, sound);
              };
            };
          } else { world.playSound(mobs[i].death, deadEntity.location, sound); };
        } else { world.playSound("game.player.die", deadEntity.location, sound); };
      };
    };
  };
});

function range(array) {
  return parseFloat((Math.random() * (array[1] - array[0]) + array[0]).toFixed(2));
};