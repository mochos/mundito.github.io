import { system, world } from "@minecraft/server";

system.runInterval(() => {
  for (const snowball of world.getDimension("overworld").getEntities({type: "cd:ohio_snowball"})) {
    for (var target of snowball.dimension.getEntities({location: snowball.location, closest: 1, excludeTypes: [ "minecraft:player" ], families: [ "mob" ]})) {};
    snowball.teleport(snowball.location, { facingLocation: target.getHeadLocation(), keepVelocity: true });
    setVelocity(snowball, { x: (snowball.getVelocity().x * 0.8) + (snowball.getViewDirection().x * 0.4), y: (snowball.getVelocity().y * 0.8) + (snowball.getViewDirection().y * 0.4), z: (snowball.getVelocity().z * 0.8) + (snowball.getViewDirection().z * 0.4) });
  };
});

function setVelocity(entity, vector) {
  entity.clearVelocity();
  entity.applyImpulse(vector);
};