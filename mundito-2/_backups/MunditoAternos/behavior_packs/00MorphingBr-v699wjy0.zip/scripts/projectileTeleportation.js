import { world } from "@minecraft/server";

world.afterEvents.projectileHit.subscribe(data => {
  if (data.getEntityHit()) {
    const entity = data.getEntityHit().entity;
    if (entity.typeId == "minecraft:player" && entity.getComponent("minecraft:variant").value == 9) {
      for (let i = 0; i < 1000; i++) {
        let location = { x: range([entity.location.x + 4, entity.location.x - 4]), z: range([entity.location.z + 4, entity.location.z - 4]) };
        if (getGroundLevel(location, entity.dimension, entity.location.y + 4) != undefined) {
          entity.teleport({ x: location.x, y: getGroundLevel(location, entity.dimension, entity.location.y + 4), z: location.z }, { checkForBlocks: true });
          world.playSound("mob.endermen.portal", entity.location);
          break;
        };
      };
    };
  };
});

function range(array) {
  return Math.random() * (array[1] - array[0]) + array[0];
};

function getGroundLevel(location, dimension, maxHeight = 320) {
  maxHeight = Math.ceil(maxHeight);
  for (let i = maxHeight; i > -64; i--) {
    if (dimension.getBlock({ x: location.x, y: i - 1, z: location.z }).isSolid()) { return i; };
  };
  return undefined;
};