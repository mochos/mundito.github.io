export const mobs = [
  {
    id: "morph:player",
    entity: "minecraft:player",
    name: "Human",
    variant: 0,
    obtainable: false
  },
  {
    id: "morph:zombie",
    entity: "minecraft:zombie",
    name: "Zombie",
    variant: 1,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_zombie",
    entity: "minecraft:zombie",
    name: "Baby Zombie",
    variant: 1,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:cow",
    entity: "minecraft:cow",
    name: "Cow",
    variant: 2,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_cow",
    entity: "minecraft:cow",
    name: "Baby Cow",
    variant: 2,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:skeleton",
    entity: "minecraft:skeleton",
    name: "Skeleton",
    variant: 3
  },
  {
    id: "morph:chicken",
    entity: "minecraft:chicken",
    name: "Chicken",
    variant: 4,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_chicken",
    entity: "minecraft:chicken",
    name: "Baby Chicken",
    variant: 4,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:creeper",
    entity: "minecraft:creeper",
    name: "Creeper",
    variant: 5,
    condition: "!entity.getComponent('minecraft:is_charged')"
  },
  {
    id: "morph:charged_creeper",
    entity: "minecraft:creeper",
    name: "Charged Creeper",
    variant: 5,
    condition: "entity.getComponent('minecraft:is_charged')"
  },
  {
    id: "morph:white_sheep",
    entity: "minecraft:sheep",
    name: "White Sheep",
    variant: 6,
    condition: "(!entity.getComponent('minecraft:color') || entity.getComponent('minecraft:color').value == 0) && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_white_sheep",
    entity: "minecraft:sheep",
    name: "Baby White Sheep",
    variant: 6,
    condition: "(!entity.getComponent('minecraft:color') || entity.getComponent('minecraft:color').value == 0) && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_white_sheep",
    entity: "minecraft:sheep",
    name: "Sheared White Sheep",
    variant: 6,
    condition: "(!entity.getComponent('minecraft:color') || entity.getComponent('minecraft:color').value == 0) && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:orange_sheep",
    entity: "minecraft:sheep",
    name: "Orange Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 1 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_orange_sheep",
    entity: "minecraft:sheep",
    name: "Baby Orange Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 1 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_orange_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Orange Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 1 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:magenta_sheep",
    entity: "minecraft:sheep",
    name: "Magenta Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 2 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_magenta_sheep",
    entity: "minecraft:sheep",
    name: "Baby Magenta Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 2 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_magenta_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Magenta Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 2 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:light_blue_sheep",
    entity: "minecraft:sheep",
    name: "Light Blue Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 3 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_light_blue_sheep",
    entity: "minecraft:sheep",
    name: "Baby Light Blue Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 3 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_light_blue_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Light Blue Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 3 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:yellow_sheep",
    entity: "minecraft:sheep",
    name: "Yellow Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 4 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_yellow_sheep",
    entity: "minecraft:sheep",
    name: "Baby Yellow Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 4 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_yellow_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Yellow Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 4 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:lime_sheep",
    entity: "minecraft:sheep",
    name: "Lime Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 5 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_lime_sheep",
    entity: "minecraft:sheep",
    name: "Baby Lime Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 5 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_lime_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Lime Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 5 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:pink_sheep",
    entity: "minecraft:sheep",
    name: "Pink Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 6 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_pink_sheep",
    entity: "minecraft:sheep",
    name: "Baby Pink Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 6 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_pink_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Pink Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 6 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:gray_sheep",
    entity: "minecraft:sheep",
    name: "Gray Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 7 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_gray_sheep",
    entity: "minecraft:sheep",
    name: "Baby Gray Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 7 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_gray_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Gray Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 7 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:light_gray_sheep",
    entity: "minecraft:sheep",
    name: "Light Gray Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 8 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_light_gray_sheep",
    entity: "minecraft:sheep",
    name: "Baby Light Gray Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 8 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_light_gray_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Light Gray Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 8 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:cyan_sheep",
    entity: "minecraft:sheep",
    name: "Cyan Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 9 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_cyan_sheep",
    entity: "minecraft:sheep",
    name: "Baby Cyan Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 9 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_cyan_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Cyan Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 9 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:purple_sheep",
    entity: "minecraft:sheep",
    name: "Purple Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 10 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_purple_sheep",
    entity: "minecraft:sheep",
    name: "Baby Purple Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 10 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_purple_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Purple Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 10 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:blue_sheep",
    entity: "minecraft:sheep",
    name: "Blue Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 11 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_blue_sheep",
    entity: "minecraft:sheep",
    name: "Baby Blue Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 11 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_blue_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Blue Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 11 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:brown_sheep",
    entity: "minecraft:sheep",
    name: "Brown Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 12 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_brown_sheep",
    entity: "minecraft:sheep",
    name: "Baby Brown Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 12 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_brown_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Brown Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 12 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:green_sheep",
    entity: "minecraft:sheep",
    name: "Green Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 13 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_green_sheep",
    entity: "minecraft:sheep",
    name: "Baby Green Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 13 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_green_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Green Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 13 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:red_sheep",
    entity: "minecraft:sheep",
    name: "Red Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 14 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_red_sheep",
    entity: "minecraft:sheep",
    name: "Baby Red Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 14 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_red_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Red Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 14 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:black_sheep",
    entity: "minecraft:sheep",
    name: "Black Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 15 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:baby_black_sheep",
    entity: "minecraft:sheep",
    name: "Baby Black Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 15 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_black_sheep",
    entity: "minecraft:sheep",
    name: "Sheared Black Sheep",
    variant: 6,
    condition: "entity.getComponent('minecraft:color').value == 15 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:spider",
    entity: "minecraft:spider",
    name: "Spider",
    variant: 7
  },
  {
    id: "morph:pig",
    entity: "minecraft:pig",
    name: "Pig",
    variant: 8,
    condition: "!entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_saddled')"
  },
  {
    id: "morph:baby_pig",
    entity: "minecraft:pig",
    name: "Baby Pig",
    variant: 8,
    condition: "entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_saddled')"
  },
  {
    id: "morph:saddled_pig",
    entity: "minecraft:pig",
    name: "Saddled Pig",
    variant: 8,
    condition: "!entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_saddled')"
  },
  {
    id: "morph:enderman",
    entity: "minecraft:enderman",
    name: "Enderman",
    variant: 9
  },
  {
    id: "morph:bat",
    entity: "minecraft:bat",
    name: "Bat",
    variant: 10
  },
  {
    id: "morph:zombified_piglin",
    entity: "minecraft:zombie_pigman",
    name: "Zombified Piglin",
    variant: 11,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_zombified_piglin",
    entity: "minecraft:zombie_pigman",
    name: "Baby Zombified Piglin",
    variant: 11,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:fox",
    entity: "minecraft:fox",
    name: "Fox",
    variant: 12,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:fox' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:fox' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_fox",
    entity: "minecraft:fox",
    name: "Baby Fox",
    variant: 12,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:fox' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:fox' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:arctic_fox",
    entity: "minecraft:fox",
    name: "Arctic Fox",
    variant: 12,
    condition: "entity.getComponent(entity.typeId == 'minecraft:fox' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_arctic_fox",
    entity: "minecraft:fox",
    name: "Baby Arctic Fox",
    variant: 12,
    condition: "entity.getComponent(entity.typeId == 'minecraft:fox' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:drowned",
    entity: "minecraft:drowned",
    name: "Drowned",
    variant: 13,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_drowned",
    entity: "minecraft:drowned",
    name: "Baby Drowned",
    variant: 13,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:plains_villager",
    entity: "minecraft:villager_v2",
    name: "Plains Villager",
    variant: 14,
    condition: "(!entity.getComponent('minecraft:mark_variant') || entity.getComponent('minecraft:mark_variant').value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_plains_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Plains Villager",
    variant: 14,
    condition: "(!entity.getComponent('minecraft:mark_variant') || entity.getComponent('minecraft:mark_variant').value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:desert_villager",
    entity: "minecraft:villager_v2",
    name: "Desert Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_desert_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Desert Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:jungle_villager",
    entity: "minecraft:villager_v2",
    name: "Jungle Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 2 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_jungle_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Jungle Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 2 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:savanna_villager",
    entity: "minecraft:villager_v2",
    name: "Savanna Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 3 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_savanna_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Savanna Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 3 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:snow_villager",
    entity: "minecraft:villager_v2",
    name: "Snow Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 4 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_snow_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Snow Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 4 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:swamp_villager",
    entity: "minecraft:villager_v2",
    name: "Swamp Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 5 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_swamp_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Swamp Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 5 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:taiga_villager",
    entity: "minecraft:villager_v2",
    name: "Taiga Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 6 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_taiga_villager",
    entity: "minecraft:villager_v2",
    name: "Baby Taiga Villager",
    variant: 14,
    condition: "entity.getComponent('minecraft:mark_variant').value == 6 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:wither_skeleton",
    entity: "minecraft:wither_skeleton",
    name: "Wither Skeleton",
    variant: 15
  },
  {
    id: "morph:snow_golem",
    entity: "minecraft:snow_golem",
    name: "Snow Golem",
    variant: 16,
    condition: "!entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:sheared_snow_golem",
    entity: "minecraft:snow_golem",
    name: "Sheared Snow Golem",
    variant: 16,
    condition: "entity.getComponent('minecraft:is_sheared')"
  },
  {
    id: "morph:blaze",
    entity: "minecraft:blaze",
    name: "Blaze",
    variant: 17
  },
  {
    id: "morph:white_cat",
    entity: "minecraft:cat",
    name: "White Cat",
    variant: 18,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_white_cat",
    entity: "minecraft:cat",
    name: "Baby White Cat",
    variant: 18,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tuxedo_cat",
    entity: "minecraft:cat",
    name: "Tuxedo Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_tuxedo_cat",
    entity: "minecraft:cat",
    name: "Baby Tuxedo Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:red_cat",
    entity: "minecraft:cat",
    name: "Red Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_red_cat",
    entity: "minecraft:cat",
    name: "Baby Red Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:siamese_cat",
    entity: "minecraft:cat",
    name: "Siamese Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_siamese_cat",
    entity: "minecraft:cat",
    name: "Baby Siamese Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:british_cat",
    entity: "minecraft:cat",
    name: "British Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_british_cat",
    entity: "minecraft:cat",
    name: "Baby British Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:calico_cat",
    entity: "minecraft:cat",
    name: "Calico Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 5 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_calico_cat",
    entity: "minecraft:cat",
    name: "Baby Calico Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 5 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:persian_cat",
    entity: "minecraft:cat",
    name: "Persian Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 6 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_persian_cat",
    entity: "minecraft:cat",
    name: "Baby Persian Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 6 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:ragdoll_cat",
    entity: "minecraft:cat",
    name: "Ragdoll Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 7 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_ragdoll_cat",
    entity: "minecraft:cat",
    name: "Baby Ragdoll Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 7 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tabby_cat",
    entity: "minecraft:cat",
    name: "Tabby Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 8 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_tabby_cat",
    entity: "minecraft:cat",
    name: "Baby Tabby Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 8 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:black_cat",
    entity: "minecraft:cat",
    name: "Black Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 9 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_black_cat",
    entity: "minecraft:cat",
    name: "Baby Black Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 9 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:jellie_cat",
    entity: "minecraft:cat",
    name: "Jellie Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 10 && !entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_jellie_cat",
    entity: "minecraft:cat",
    name: "Baby Jellie Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 10 && entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_white_cat",
    entity: "minecraft:cat",
    name: "Tamed White Cat",
    variant: 18,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_white_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby White Cat",
    variant: 18,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_tuxedo_cat",
    entity: "minecraft:cat",
    name: "Tamed Tuxedo Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_tuxedo_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Tuxedo Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_red_cat",
    entity: "minecraft:cat",
    name: "Tamed Red Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_red_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Red Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_siamese_cat",
    entity: "minecraft:cat",
    name: "Tamed Siamese Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_siamese_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Siamese Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_british_cat",
    entity: "minecraft:cat",
    name: "Tamed British Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_british_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby British Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_calico_cat",
    entity: "minecraft:cat",
    name: "Tamed Calico Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 5 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_calico_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Calico Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 5 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_persian_cat",
    entity: "minecraft:cat",
    name: "Tamed Persian Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 6 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_persian_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Persian Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 6 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_ragdoll_cat",
    entity: "minecraft:cat",
    name: "Tamed Ragdoll Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 7 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_ragdoll_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Ragdoll Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 7 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_tabby_cat",
    entity: "minecraft:cat",
    name: "Tamed Tabby Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 8 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_tabby_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Tabby Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 8 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_black_cat",
    entity: "minecraft:cat",
    name: "Tamed Black Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 9 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_black_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Black Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 9 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_jellie_cat",
    entity: "minecraft:cat",
    name: "Tamed Jellie Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 10 && !entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_jellie_cat",
    entity: "minecraft:cat",
    name: "Tamed Baby Jellie Cat",
    variant: 18,
    condition: "entity.getComponent(entity.typeId == 'minecraft:cat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 10 && entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:husk",
    entity: "minecraft:husk",
    name: "Husk",
    variant: 19,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_husk",
    entity: "minecraft:husk",
    name: "Baby Husk",
    variant: 19,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:wolf",
    entity: "minecraft:wolf",
    name: "Wolf",
    variant: 20,
    condition: "!entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:baby_wolf",
    entity: "minecraft:wolf",
    name: "Baby Wolf",
    variant: 20,
    condition: "entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_wolf",
    entity: "minecraft:wolf",
    name: "Tamed Wolf",
    variant: 20,
    condition: "!entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:tamed_baby_wolf",
    entity: "minecraft:wolf",
    name: "Tamed Baby Wolf",
    variant: 20,
    condition: "entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_tamed')"
  },
  {
    id: "morph:piglin",
    entity: "minecraft:piglin",
    name: "Piglin",
    variant: 21,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_piglin",
    entity: "minecraft:piglin",
    name: "Baby Piglin",
    variant: 21,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:small_salmon",
    entity: "minecraft:salmon",
    name: "Small Salmon",
    variant: 22,
    condition: "entity.getComponent('minecraft:scale').value == 0.5"
  },
  {
    id: "morph:salmon",
    entity: "minecraft:salmon",
    name: "Salmon",
    variant: 22,
    condition: "entity.getComponent('minecraft:scale').value == 1.0"
  },
  {
    id: "morph:large_salmon",
    entity: "minecraft:salmon",
    name: "Large Salmon",
    variant: 22,
    condition: "entity.getComponent('minecraft:scale').value == 1.5"
  },
  {
    id: "morph:iron_golem",
    entity: "minecraft:iron_golem",
    name: "Iron Golem",
    variant: 23
  },
  {
    id: "morph:lucy_axolotl",
    entity: "minecraft:axolotl",
    name: "Lucy Axolotl",
    variant: 24,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_lucy_axolotl",
    entity: "minecraft:axolotl",
    name: "Baby Lucy Axolotl",
    variant: 24,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:cyan_axolotl",
    entity: "minecraft:axolotl",
    name: "Cyan Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_cyan_axolotl",
    entity: "minecraft:axolotl",
    name: "Baby Cyan Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:gold_axolotl",
    entity: "minecraft:axolotl",
    name: "Gold Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_gold_axolotl",
    entity: "minecraft:axolotl",
    name: "Baby Gold Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:wild_axolotl",
    entity: "minecraft:axolotl",
    name: "Wild Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_wild_axolotl",
    entity: "minecraft:axolotl",
    name: "Baby Wild Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:blue_axolotl",
    entity: "minecraft:axolotl",
    name: "Blue Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_blue_axolotl",
    entity: "minecraft:axolotl",
    name: "Baby Blue Axolotl",
    variant: 24,
    condition: "entity.getComponent(entity.typeId == 'minecraft:axolotl' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:stray",
    entity: "minecraft:stray",
    name: "Stray",
    variant: 25
  },
  {
    id: "morph:ocelot",
    entity: "minecraft:ocelot",
    name: "Ocelot",
    variant: 26,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_ocelot",
    entity: "minecraft:ocelot",
    name: "Baby Ocelot",
    variant: 26,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:vindicator",
    entity: "minecraft:vindicator",
    name: "Vindicator",
    variant: 27
  },
  {
    id: "morph:cod",
    entity: "minecraft:cod",
    name: "Cod",
    variant: 28
  },
  {
    id: "morph:hoglin",
    entity: "minecraft:hoglin",
    name: "Hoglin",
    variant: 29,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_hoglin",
    entity: "minecraft:hoglin",
    name: "Baby Hoglin",
    variant: 29,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:squid",
    entity: "minecraft:squid",
    name: "Squid",
    variant: 30,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_squid",
    entity: "minecraft:squid",
    name: "Baby Squid",
    variant: 30,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:piglin_brute",
    entity: "minecraft:piglin_brute",
    name: "Piglin Brute",
    variant: 31
  },
  {
    id: "morph:creamy_llama",
    entity: "minecraft:llama",
    name: "Creamy Llama",
    variant: 32,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_creamy_llama",
    entity: "minecraft:llama",
    name: "Baby Creamy Llama",
    variant: 32,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:white_llama",
    entity: "minecraft:llama",
    name: "White Llama",
    variant: 32,
    condition: "entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_white_llama",
    entity: "minecraft:llama",
    name: "Baby White Llama",
    variant: 32,
    condition: "entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:brown_llama",
    entity: "minecraft:llama",
    name: "Brown Llama",
    variant: 32,
    condition: "entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_brown_llama",
    entity: "minecraft:llama",
    name: "Baby Brown Llama",
    variant: 32,
    condition: "entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:gray_llama",
    entity: "minecraft:llama",
    name: "Gray Llama",
    variant: 32,
    condition: "entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_gray_llama",
    entity: "minecraft:llama",
    name: "Baby Gray Llama",
    variant: 32,
    condition: "entity.getComponent(entity.typeId == 'minecraft:llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:cave_spider",
    entity: "minecraft:cave_spider",
    name: "Cave Spider",
    variant: 33
  },
  {
    id: "morph:red_mooshroom",
    entity: "minecraft:mooshroom",
    name: "Red Mooshroom",
    variant: 34,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:mooshroom' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:mooshroom' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_red_mooshroom",
    entity: "minecraft:mooshroom",
    name: "Baby Red Mooshroom",
    variant: 34,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:mooshroom' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:mooshroom' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:brown_mooshroom",
    entity: "minecraft:mooshroom",
    name: "Brown Mooshroom",
    variant: 34,
    condition: "entity.getComponent(entity.typeId == 'minecraft:mooshroom' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_brown_mooshroom",
    entity: "minecraft:mooshroom",
    name: "Baby Brown Mooshroom",
    variant: 34,
    condition: "entity.getComponent(entity.typeId == 'minecraft:mooshroom' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:plains_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Plains Zombie Villager",
    variant: 35,
    condition: "(!entity.getComponent('minecraft:mark_variant') || entity.getComponent('minecraft:mark_variant').value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_plains_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Plains Zombie Villager",
    variant: 35,
    condition: "(!entity.getComponent('minecraft:mark_variant') || entity.getComponent('minecraft:mark_variant').value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:desert_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Desert Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_desert_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Desert Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:jungle_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Jungle Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 2 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_jungle_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Jungle Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 2 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:savanna_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Savanna Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 3 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_savanna_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Savanna Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 3 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:snow_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Snow Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 4 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_snow_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Snow Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 4 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:swamp_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Swamp Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 5 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_swamp_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Swamp Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 5 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:taiga_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Taiga Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 6 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_taiga_zombie_villager",
    entity: "minecraft:zombie_villager_v2",
    name: "Baby Taiga Zombie Villager",
    variant: 35,
    condition: "entity.getComponent('minecraft:mark_variant').value == 6 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:goat",
    entity: "minecraft:goat",
    name: "Goat",
    variant: 36,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:goat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:goat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_goat",
    entity: "minecraft:goat",
    name: "Baby Goat",
    variant: 36,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:goat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:goat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:screaming_goat",
    entity: "minecraft:goat",
    name: "Screaming Goat",
    variant: 36,
    condition: "entity.getComponent(entity.typeId == 'minecraft:goat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_screaming_goat",
    entity: "minecraft:goat",
    name: "Baby Screaming Goat",
    variant: 36,
    condition: "entity.getComponent(entity.typeId == 'minecraft:goat' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:wither",
    entity: "minecraft:wither",
    name: "Wither",
    variant: 37
  },
  {
    id: "morph:dolphin",
    entity: "minecraft:dolphin",
    name: "Dolphin",
    variant: 38,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_dolphin",
    entity: "minecraft:dolphin",
    name: "Baby Dolphin",
    variant: 38,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:zoglin",
    entity: "minecraft:zoglin",
    name: "Zoglin",
    variant: 39,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_zoglin",
    entity: "minecraft:zoglin",
    name: "Baby Zoglin",
    variant: 39,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:bee",
    entity: "minecraft:bee",
    name: "Bee",
    variant: 40,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_bee",
    entity: "minecraft:bee",
    name: "Baby Bee",
    variant: 40,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:pillager",
    entity: "minecraft:pillager",
    name: "Pillager",
    variant: 41
  },
  {
    id: "morph:red_parrot",
    entity: "minecraft:parrot",
    name: "Red Parrot",
    variant: 42,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:parrot' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:parrot' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0)"
  },
  {
    id: "morph:blue_parrot",
    entity: "minecraft:parrot",
    name: "Blue Parrot",
    variant: 42,
    condition: "entity.getComponent(entity.typeId == 'minecraft:parrot' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1"
  },
  {
    id: "morph:green_parrot",
    entity: "minecraft:parrot",
    name: "Green Parrot",
    variant: 42,
    condition: "entity.getComponent(entity.typeId == 'minecraft:parrot' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2"
  },
  {
    id: "morph:cyan_parrot",
    entity: "minecraft:parrot",
    name: "Cyan Parrot",
    variant: 42,
    condition: "entity.getComponent(entity.typeId == 'minecraft:parrot' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3"
  },
  {
    id: "morph:silver_parrot",
    entity: "minecraft:parrot",
    name: "Silver Parrot",
    variant: 42,
    condition: "entity.getComponent(entity.typeId == 'minecraft:parrot' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4"
  },
  {
    id: "morph:large_slime",
    entity: "minecraft:slime",
    name: "Large Slime",
    variant: 43,
    condition: "entity.getComponent(entity.typeId == 'minecraft:slime' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4"
  },
  {
    id: "morph:medium_slime",
    entity: "minecraft:slime",
    name: "Medium Slime",
    variant: 43,
    condition: "entity.getComponent(entity.typeId == 'minecraft:slime' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2"
  },
  {
    id: "morph:small_slime",
    entity: "minecraft:slime",
    name: "Small Slime",
    variant: 43,
    condition: "entity.getComponent(entity.typeId == 'minecraft:slime' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1"
  },
  {
    id: "morph:strider",
    entity: "minecraft:strider",
    name: "Strider",
    variant: 44,
    condition: "!entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_saddled')"
  },
  {
    id: "morph:baby_strider",
    entity: "minecraft:strider",
    name: "Baby Strider",
    variant: 44,
    condition: "entity.getComponent('minecraft:is_baby') && !entity.getComponent('minecraft:is_saddled')"
  },
  {
    id: "morph:saddled_strider",
    entity: "minecraft:strider",
    name: "Saddled Strider",
    variant: 44,
    condition: "!entity.getComponent('minecraft:is_baby') && entity.getComponent('minecraft:is_saddled')"
  },
  {
    id: "morph:vex",
    entity: "minecraft:vex",
    name: "Vex",
    variant: 45
  },
  {
    id: "morph:turtle",
    entity: "minecraft:turtle",
    name: "Turtle",
    variant: 46,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_turtle",
    entity: "minecraft:turtle",
    name: "Baby Turtle",
    variant: 46,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:witch",
    entity: "minecraft:witch",
    name: "Witch",
    variant: 47
  },
  {
    id: "morph:brown_rabbit",
    entity: "minecraft:rabbit",
    name: "Brown Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && (!entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_brown_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby Brown Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && (!entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:white_rabbit",
    entity: "minecraft:rabbit",
    name: "White Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_white_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby White Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:black_rabbit",
    entity: "minecraft:rabbit",
    name: "Black Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_black_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby Black Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:splotched_rabbit",
    entity: "minecraft:rabbit",
    name: "Splotched Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_splotched_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby Splotched Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:desert_rabbit",
    entity: "minecraft:rabbit",
    name: "Desert Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_desert_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby Desert Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:salt_rabbit",
    entity: "minecraft:rabbit",
    name: "Salt Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 5 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_salt_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby Salt Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag != 'Toast' : true) && entity.getComponent(entity.typeId == 'minecraft:rabbit' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 5 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:toast_rabbit",
    entity: "minecraft:rabbit",
    name: "Toast Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag == 'Toast' : (entity.typeId == 'minecraft:player' ? entity.getComponent('minecraft:mark_variant').value == 6 : false)) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_toast_rabbit",
    entity: "minecraft:rabbit",
    name: "Baby Toast Rabbit",
    variant: 48,
    condition: "(entity.typeId == 'minecraft:rabbit' ? entity.nameTag == 'Toast' : (entity.typeId == 'minecraft:player' ? entity.getComponent('minecraft:mark_variant').value == 6 : false)) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:ghast",
    entity: "minecraft:ghast",
    name: "Ghast",
    variant: 49
  },
  {
    id: "morph:glow_squid",
    entity: "minecraft:glow_squid",
    name: "Glow Squid",
    variant: 50,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_glow_squid",
    entity: "minecraft:glow_squid",
    name: "Baby Glow Squid",
    variant: 50,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:phantom",
    entity: "minecraft:phantom",
    name: "Phantom",
    variant: 51
  },
  {
    id: "morph:polar_bear",
    entity: "minecraft:polar_bear",
    name: "Polar Bear",
    variant: 52,
    condition: "!entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_polar_bear",
    entity: "minecraft:polar_bear",
    name: "Baby Polar Bear",
    variant: 52,
    condition: "entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:large_magma_cube",
    entity: "minecraft:magma_cube",
    name: "Large Magma Cube",
    variant: 53,
    condition: "entity.getComponent(entity.typeId == 'minecraft:magma_cube' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 4"
  },
  {
    id: "morph:medium_magma_cube",
    entity: "minecraft:magma_cube",
    name: "Medium Magma Cube",
    variant: 53,
    condition: "entity.getComponent(entity.typeId == 'minecraft:magma_cube' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2"
  },
  {
    id: "morph:small_magma_cube",
    entity: "minecraft:magma_cube",
    name: "Small Magma Cube",
    variant: 53,
    condition: "entity.getComponent(entity.typeId == 'minecraft:magma_cube' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1"
  },
  {
    id: "morph:allay",
    entity: "minecraft:allay",
    name: "Allay",
    variant: 54
  },
  {
    id: "morph:ravager",
    entity: "minecraft:ravager",
    name: "Ravager",
    variant: 55
  },
  {
    id: "morph:temperate_frog",
    entity: "minecraft:frog",
    name: "Temperate Frog",
    variant: 56,
    condition: "entity.getComponent(entity.typeId == 'minecraft:frog' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0"
  },
  {
    id: "morph:cold_frog",
    entity: "minecraft:frog",
    name: "Cold Frog",
    variant: 56,
    condition: "entity.getComponent(entity.typeId == 'minecraft:frog' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1"
  },
  {
    id: "morph:warm_frog",
    entity: "minecraft:frog",
    name: "Warm Frog",
    variant: 56,
    condition: "entity.getComponent(entity.typeId == 'minecraft:frog' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2"
  },
  {
    id: "morph:evoker",
    entity: "minecraft:evocation_illager",
    name: "Evoker",
    variant: 57
  },
  {
    id: "morph:tadpole",
    entity: "minecraft:tadpole",
    name: "Tadpole",
    variant: 58
  },
  {
    id: "morph:endermite",
    entity: "minecraft:endermite",
    name: "Endermite",
    variant: 59
  },
  {
    id: "morph:wandering_trader",
    entity: "minecraft:wandering_trader",
    name: "Wandering Trader",
    variant: 60
  },
  {
    id: "morph:silverfish",
    entity: "minecraft:silverfish",
    name: "Silverfish",
    variant: 61
  },
  {
    id: "morph:creamy_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Creamy Trader Llama",
    variant: 62,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_creamy_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Baby Creamy Trader Llama",
    variant: 62,
    condition: "(!entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)) || entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 0) && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:white_trader_llama",
    entity: "minecraft:trader_llama",
    name: "White Trader Llama",
    variant: 62,
    condition: "entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_white_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Baby White Trader Llama",
    variant: 62,
    condition: "entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 1 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:brown_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Brown Trader Llama",
    variant: 62,
    condition: "entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_brown_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Baby Brown Trader Llama",
    variant: 62,
    condition: "entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 2 && entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:gray_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Gray Trader Llama",
    variant: 62,
    condition: "entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && !entity.getComponent('minecraft:is_baby')"
  },
  {
    id: "morph:baby_gray_trader_llama",
    entity: "minecraft:trader_llama",
    name: "Baby Gray Trader Llama",
    variant: 62,
    condition: "entity.getComponent(entity.typeId == 'minecraft:trader_llama' ? 'minecraft:variant' : (entity.typeId == 'minecraft:player' ? 'minecraft:mark_variant' : false)).value == 3 && entity.getComponent('minecraft:is_baby')"
  }
];