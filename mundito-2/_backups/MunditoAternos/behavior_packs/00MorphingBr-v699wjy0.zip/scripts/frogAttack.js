import { system, world } from "@minecraft/server";

world.afterEvents.entityHit.subscribe(data => {
  const { entity, hitEntity } = data;
  if (entity.typeId == "minecraft:player" && entity.getComponent("minecraft:variant").value == 56 && hitEntity) {
    if (hitEntity.id == "minecraft:player") {
      hitEntity.runCommand(`damage @s 2 entity_attack entity ${entity.name}`);
    } else if (!entity.hasTag("morph:cannot_tongue")) {
      entity.addTag("morph:cannot_tongue");
      system.runTimeout(() => {
        hitEntity.clearVelocity();
        hitEntity.applyImpulse({ x: (entity.location.x - hitEntity.location.x) / 2, y: (entity.location.y - hitEntity.location.y) / 2, z: (entity.location.z - hitEntity.location.z) / 2 });
        let knockback = { x: (hitEntity.location.x - entity.location.x) / 2, y: (hitEntity.location.y - entity.location.y) / 2, z: (hitEntity.location.z - entity.location.z) / 2 };
        system.runTimeout(() => {
          hitEntity.runCommand(`damage @s 2 entity_attack entity ${entity.name}`);
          system.run(() => {
            hitEntity.clearVelocity();
            hitEntity.applyKnockback(knockback.x, knockback.z, 1, 0.5);
          });
        }, 3);
      }, 1);
      system.runTimeout(() => {
        entity.removeTag("morph:cannot_tongue");
      }, 19);
    };
  };
});