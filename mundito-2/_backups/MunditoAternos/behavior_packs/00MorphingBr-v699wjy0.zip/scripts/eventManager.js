import { system, world } from "@minecraft/server";
import { mobs } from "morphables.js";

let morphEvents = []; for (let i = 0; i < mobs.length; i++) { morphEvents.push(mobs[i].id) };

let addResetEvents = [
  "morph:zombie_convert_to_drowned",
  "morph:skeleton_become_stray_event",
  "morph:pig_become_zombie",
  "morph:villager_become_witch",
  "morph:villager_become_zombie",
  "morph:husk_convert_to_zombie",
  "morph:piglin_become_zombie_event",
  "morph:hoglin_become_zombie_event",
  "morph:piglin_brute_become_zombie_event",
  "morph:mooshroom_become_cow",
  "morph:zombie_villager_become_villager",
  "morph:frog_ageable_grow_up"
];

world.beforeEvents.dataDrivenEntityTriggerEvent.subscribe(data => {
  const { entity, id } = data;
  if (entity.typeId == "minecraft:player" && (morphEvents.includes(id) || addResetEvents.includes(id)) && !entity.hasTag("morph:morph_cooldown")) {
    data.cancel = true;
    system.run(() => {
      entity.addTag("morph:morph_cooldown");
      entity.triggerEvent("morph:post_morph");
      entity.triggerEvent("morph:reset");
      entity.triggerEvent(id);
      entity.removeTag("morph:morph_cooldown");
    });
  };
});

world.afterEvents.dataDrivenEntityTriggerEvent.subscribe(data => {
  const { entity, id } = data;
  if (entity.typeId == "minecraft:player" && (morphEvents.includes(id) || addResetEvents.includes(id)) && entity.gameMode != "creative") {
    let previousHealth = {
      current: entity.getComponent("minecraft:health").current,
      max: entity.getComponent("minecraft:health").value
    };
    system.runTimeout(() => {
      if (entity.getComponent("minecraft:health").value > previousHealth.max && previousHealth.max == previousHealth.current) {
        entity.getComponent("minecraft:health").setCurrent(previousHealth.current);
      };
    }, 1);
  };
});