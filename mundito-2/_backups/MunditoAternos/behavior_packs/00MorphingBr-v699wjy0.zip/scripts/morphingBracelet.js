import { system, world, MolangVariableMap } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { mobs } from "morphables.js";

world.afterEvents.itemDefinitionEvent.subscribe(data => {
  const { eventName, source } = data;

  if (eventName == "morph:morphing_bracelet") {
    const item_slot = source.selectedSlot;
    const item = source.getComponent("minecraft:inventory").container.getItem(item_slot);
    
    let morphMenu = new ActionFormData();
    let onClick = [];
    
    let mobNames = []; for (let i = 0; i < mobs.length; i++) { mobNames.push(mobs[i].name); }; mobNames.sort();
    let sortedMobs = [ mobs[0] ]; for (let i = 0; i < mobs.length; i++) { if (mobs[0].name != mobNames[i]) { sortedMobs.push(mobs[mobs.findIndex(x => x.name == mobNames[i])]); }; };
  
    morphMenu.title("Morph Menu");

    for (let i = 0; i < sortedMobs.length; i++) {  
      if ((item.getLore()[0] && item.getLore()[0].split(`\n`).includes(sortedMobs[i].id)) && source.getMorph().id != sortedMobs[i].id) {
        morphMenu.button(sortedMobs[i].name, `textures/icons/morph_menu/${sortedMobs[i].entity.split(":")[1]}/${sortedMobs[i].id.split(":")[1]}`);
        onClick.push(sortedMobs[i].id);
      };
    };

    if (onClick.length > 0) {
      morphMenu.show(source).then(result => {
        if (!result.canceled) {
          if (source.gameMode == "creative" || onClick[result.selection] == "morph:player") {
            source.triggerEvent(onClick[result.selection]);
          } else if (item.getComponent("minecraft:durability").maxDurability - 1 > item.getComponent("minecraft:durability").damage) {
            source.triggerEvent(onClick[result.selection]);
            item.getComponent("minecraft:durability").damage = item.getComponent("minecraft:durability").damage + 1;
            source.getComponent("minecraft:inventory").container.setItem(item_slot, item);
          } else if (item.getComponent("minecraft:durability").maxDurability - 1 <= item.getComponent("minecraft:durability").damage) {
            source.getComponent("minecraft:inventory").container.setItem(item_slot, undefined);
            world.playSound("random.break", source.location, { volume: 1.0, pitch: 0.90 });
          };
        };
      });
    } else { source.sendMessage({ rawtext: [{ text: "§7" }, { translate: "item.morph:morphing_bracelet.empty" }, { text: "§r" }]}); };
  };
});

world.afterEvents.entityDie.subscribe(data => {
  const { damageSource, deadEntity } = data;
  if (damageSource.damagingEntity && damageSource.damagingEntity.typeId == "minecraft:player") {
    let mob = mobs[mobs.findIndex(function(i) { return i.entity == deadEntity.typeId && (i.condition == undefined ? true : eval(i.condition.replace(new RegExp("\\bentity\\b","g"), "deadEntity"))) && (i.obtainable == undefined ? true : i.obtainable)})].id;
    if (hasAvailableSpot(damageSource.damagingEntity, mob)) {
      system.run(() => { addMob(damageSource.damagingEntity, mob); });
      world.playSound("beacon.activate", damageSource.damagingEntity.location);
    };
  };
});

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    if (hasAvailableSpot(player, player.getMorph().id)) { addMob(player, player.getMorph().id); };
    if (player.getComponent("minecraft:variant").value != 0) { player.runCommand("execute unless entity @s[hasitem={item=morph:morphing_bracelet}] run event entity @s morph:player"); };
  };
});

function hasAvailableSpot(entity, morph) {
  for (let slot = 0; slot < entity.getComponent("minecraft:inventory").container.size; slot++) {
    let item = entity.getComponent("minecraft:inventory").container.getItem(slot);
    if (item && item.typeId == "morph:morphing_bracelet") {
      if (!item.getLore()[0] || (item.getLore()[0] && !item.getLore()[0].split(`\n`).includes(morph))) { return true; };
    };
  };
};

function addMob(entity, morph) {
  for (let slot = 0; slot < entity.getComponent("minecraft:inventory").container.size; slot++) {
    let item = entity.getComponent("minecraft:inventory").container.getItem(slot);
    if (item && item.typeId == "morph:morphing_bracelet") {
      if (!item.getLore()[0]) {
        item.setLore([`\n§r§7Mobs:\n${morph}`]);
        entity.getComponent("minecraft:inventory").container.setItem(slot, item);
      } else {
        if (!item.getLore()[0].split(`\n`).includes(morph)) {
          item.setLore([item.getLore()[0] + `\n${morph}`]);
          entity.getComponent("minecraft:inventory").container.setItem(slot, item);
        };
      };
    };
  };
};

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot);
    if (item != undefined && item.typeId == "morph:morphing_bracelet" && player.dimension.getBlock({ x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) }).typeId == "minecraft:soul_sand") {
      if (item.getComponent("minecraft:durability").damage > 0) {
        player.dimension.spawnParticle("minecraft:soul_particle", { x: (player.location.x - 0.5) + Math.random(), y: player.location.y + 0.2, z: (player.location.z - 0.5) + Math.random() }, new MolangVariableMap());
        world.playSound("bloom.sculk_catalyst", player.location);
      };
    };
  };
}, 2);

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot);
    if (item != undefined && item.typeId == "morph:morphing_bracelet" && player.dimension.getBlock({ x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) }).typeId == "minecraft:soul_sand") {
      if (item.getComponent("minecraft:durability").damage > 0) {
        item.getComponent("minecraft:durability").damage = item.getComponent("minecraft:durability").damage - 1;
        player.getComponent("minecraft:inventory").container.setItem(player.selectedSlot, item);
      };
    };
  };
}, 19);