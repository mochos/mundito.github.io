import { system, world, MinecraftEffectTypes } from "@minecraft/server";

world.afterEvents.entityHit.subscribe(data => {
  const { entity, hitEntity, hitBlock } = data;
  if ((hitEntity && !hitBlock) && entity.typeId == "minecraft:player" && !hitEntity.hasTag("damaged")) {
    damagedTag(hitEntity);
    if (entity.getComponent("minecraft:variant").value == 15) { hitEntity.addEffect(MinecraftEffectTypes.wither, 10 * 20); };
    if (entity.getComponent("minecraft:variant").value == 19) { hitEntity.addEffect(MinecraftEffectTypes.hunger, 30 * 20); };
    if (entity.getComponent("minecraft:variant").value == 23) { system.run(() => { hitEntity.applyImpulse({ x: 0, y: hitEntity.getVelocity().y, z: 0 })}); };
    if (entity.getComponent("minecraft:variant").value == 33) { hitEntity.addEffect(MinecraftEffectTypes.poison, 7 * 20); };
    if (entity.getComponent("minecraft:variant").value == 40 && entity.getComponent("minecraft:mark_variant").value != 1) {
      hitEntity.addEffect(MinecraftEffectTypes.poison, 10 * 20);
      if (entity.gameMode != "creative") {
        entity.triggerEvent("morph:bee_countdown_to_perish");
        world.playSound("mob.bee.sting", entity.location);
      };
    };
  };
});

function damagedTag(entity) {
  entity.addTag("damaged");
  system.runTimeout(() => {
    try { entity.removeTag("damaged"); } catch {};
  }, 9);
};