import {system, world} from "@minecraft/server";

system.runInterval(()=>{
	world.getDimension("overworld").runCommandAsync(`say test`);
},1);