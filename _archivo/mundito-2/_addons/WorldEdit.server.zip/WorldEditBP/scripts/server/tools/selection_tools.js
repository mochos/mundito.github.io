import { Tool } from "./base_tool.js";
import { Tools } from "./tool_manager.js";
import { Server } from "./../../library/Minecraft.js";
class SelectionTool extends Tool {
    constructor() {
        super(...arguments);
        this.permission = "worldedit.selection.pos";
        this.useOn = function (self, player, session, loc) {
            Server.command.callCommand(player, player.isSneaking ? "pos1" : "pos2", [`${loc.x}`, `${loc.y}`, `${loc.z}`]);
        };
        this.breakOn = function (self, player, session, loc) {
            Server.command.callCommand(player, "pos1", [`${loc.x}`, `${loc.y}`, `${loc.z}`]);
        };
    }
}
Tools.register(SelectionTool, "selection_wand");
class FarSelectionTool extends Tool {
    constructor() {
        super(...arguments);
        this.permission = "worldedit.selection.hpos";
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        this.use = function (self, player, session) {
            Server.command.callCommand(player, player.isSneaking ? "hpos1" : "hpos2");
        };
    }
}
Tools.register(FarSelectionTool, "far_selection_wand");
