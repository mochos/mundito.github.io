import "./hotbar_menus.js";
import "./config_menu.js";
