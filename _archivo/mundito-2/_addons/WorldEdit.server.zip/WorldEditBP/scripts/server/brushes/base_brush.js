import { RawText } from "./../../library/Minecraft.js";
import config from "config.js";
/**
 * This class is the base for all brush types available in WorldEdit.
 */
export class Brush {
    assertSizeInRange(size) {
        if (size > config.maxBrushRadius) {
            throw RawText.translate("commands.wedit:brush.tooLarge").with(config.maxBrushRadius.toString());
        }
    }
}
